'use client';

import Link from 'next/link';
import { useEffect } from 'react';

export default function ErrorPage({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    console.error(error);
  }, [error]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50 relative overflow-hidden px-4">
      <div className="absolute inset-0 bg-gradient-to-br from-amber-50 via-emerald-50/30 to-white -z-10" />
      <div className="max-w-md w-full bg-white rounded-3xl shadow-xl shadow-slate-200/50 border border-slate-200 p-10 text-center">
        <h1 className="text-3xl font-extrabold text-slate-900 mb-3">
          Something went wrong
        </h1>
        <p className="text-slate-600 mb-8">
          We hit an unexpected error. Please try again, or return to the
          homepage.
        </p>
        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <button
            onClick={() => reset()}
            className="bg-emerald-600 hover:bg-emerald-700 text-white px-6 py-3 rounded-full font-medium transition-colors"
          >
            Try again
          </button>
          <Link
            href="/"
            className="bg-white hover:bg-slate-50 text-emerald-700 border-2 border-emerald-200 px-6 py-3 rounded-full font-medium transition-colors"
          >
            Go home
          </Link>
        </div>
      </div>
    </div>
  );
}
