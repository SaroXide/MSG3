import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { Phone, Mail, MapPin } from 'lucide-react';

export default function Contact() {
  return (
    <>
      <Header />
      <main className="bg-slate-50 min-h-screen">
        <div className="relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-amber-50 via-emerald-50/30 to-white -z-10" />
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-24 text-center">
            <h1 className="text-4xl md:text-5xl font-extrabold text-slate-900 mb-4">Contact Us</h1>
            <p className="text-xl text-slate-600">
              Get in touch with a licensed advisor today. We are here to help you find the right coverage.
            </p>
          </div>
        </div>

        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 pb-24">
          <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-8 md:p-12">
            <h2 className="text-2xl font-bold text-slate-900 mb-8 text-center">Get in Touch</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="flex flex-col items-center text-center">
                <div className="w-12 h-12 bg-emerald-100 text-emerald-600 rounded-xl flex items-center justify-center mb-4">
                  <Phone className="w-6 h-6" />
                </div>
                <p className="font-semibold text-slate-900 mb-1">Phone</p>
                <a href="tel:4378002223" className="text-emerald-600 hover:text-emerald-700 font-medium">(437) 800-2223</a>
              </div>
              <div className="flex flex-col items-center text-center">
                <div className="w-12 h-12 bg-emerald-100 text-emerald-600 rounded-xl flex items-center justify-center mb-4">
                  <Mail className="w-6 h-6" />
                </div>
                <p className="font-semibold text-slate-900 mb-1">Email</p>
                <a href="mailto:info@maplesolutionsgroup.ca" className="text-emerald-600 hover:text-emerald-700 font-medium">info@maplesolutionsgroup.ca</a>
              </div>
              <div className="flex flex-col items-center text-center">
                <div className="w-12 h-12 bg-emerald-100 text-emerald-600 rounded-xl flex items-center justify-center mb-4">
                  <MapPin className="w-6 h-6" />
                </div>
                <p className="font-semibold text-slate-900 mb-1">Service Area</p>
                <p className="text-slate-600">Servicing all of Ontario, Canada</p>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
}
