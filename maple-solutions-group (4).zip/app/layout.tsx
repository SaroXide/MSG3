import type { Metadata } from 'next';
import './globals.css';
import Script from 'next/script';

export const metadata: Metadata = {
  title: 'Maple Solutions Group | Insurance Advisors in Ontario',
  description: 'Connect with experienced, handpicked insurance advisors in Ontario. Access 40+ insurance providers for life, health, home, auto, and business insurance.',
  icons: {
    icon: '/logo.png',
    apple: '/logo.png',
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="scroll-smooth">
      <body className="antialiased bg-slate-50 text-slate-900 min-h-screen flex flex-col" suppressHydrationWarning>

        {/* Fix AI Studio preview: patch JSON.stringify to handle DOM elements and circular refs */}
        <script dangerouslySetInnerHTML={{ __html: `
          (function() {
            var _orig = JSON.stringify;
            JSON.stringify = function(value, replacer, space) {
              var seen = typeof WeakSet !== 'undefined' ? new WeakSet() : null;
              return _orig(value, function(key, val) {
                if (typeof Element !== 'undefined' && val instanceof Element) return '[HTMLElement]';
                if (typeof Node !== 'undefined' && val instanceof Node) return '[Node]';
                if (val !== null && typeof val === 'object') {
                  if (seen) {
                    if (seen.has(val)) return '[Circular]';
                    seen.add(val);
                  }
                }
                return replacer ? replacer.call(this, key, val) : val;
              }, space);
            };
          })();
        `}} />

        {/* Google Tag (gtag.js) */}
        <Script
          async
          src="https://www.googletagmanager.com/gtag/js?id=AW-17623426671"
          strategy="afterInteractive"
        />
        <Script
          id="google-tag-init"
          strategy="afterInteractive"
          dangerouslySetInnerHTML={{
            __html: `
              window.dataLayer = window.dataLayer || [];
              function gtag(){dataLayer.push(arguments);}
              gtag('js', new Date());
              gtag('config', 'AW-17623426671');
            `,
          }}
        />

        {/* Hotjar / Contentsquare Tracking Script */}
        <Script 
          src="https://t.contentsquare.net/uxa/e22602bc3b7e8.js" 
          strategy="afterInteractive" 
        />

        {children}
      </body>
    </html>
  );
}