import Link from 'next/link';

export default function NotFound() {
  return (
    <div className="flex items-center justify-center min-h-[70vh] flex-col text-center px-4">
      <h2 className="text-3xl font-bold mb-4">404 - Page Not Found</h2>
      <p className="text-slate-600 mb-8 max-w-md">The page you are looking for does not exist or has been moved.</p>
      <Link href="/" className="bg-emerald-600 text-white px-6 py-3 rounded-full font-medium hover:bg-emerald-700 transition">
        Return Home
      </Link>
    </div>
  );
}
