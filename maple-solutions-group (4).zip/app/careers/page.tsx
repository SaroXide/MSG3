import Header from '@/components/Header';
import Footer from '@/components/Footer';

export default function Careers() {
  return (
    <>
      <Header />
      <main className="bg-slate-50 min-h-screen">
        <div className="relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-amber-50 via-emerald-50/30 to-white -z-10" />
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-24 text-center">
            <h1 className="text-4xl md:text-5xl font-extrabold text-slate-900 mb-6">Become a Licensed Insurance Advisor</h1>
            <p className="text-xl text-slate-600 max-w-3xl mx-auto">
              Maple Solutions Group is always looking for motivated individuals who want to build a career helping people protect their families and plan for their financial future.
            </p>
          </div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-24">
          <div className="max-w-3xl mx-auto bg-white rounded-3xl p-8 md:p-12 border border-slate-200 shadow-xl shadow-slate-200/50">
            <p className="text-lg text-slate-700 mb-8 leading-relaxed">
              If you are interested in becoming a licensed insurance advisor or expanding your career in the financial services industry, we would love to hear from you. Please send your resume and a brief introduction to <a href="mailto:careers@maplesolutionsgroup.ca" className="text-emerald-600 font-semibold hover:underline">careers@maplesolutionsgroup.ca</a>.
            </p>

            <h2 className="text-2xl font-bold text-slate-900 mb-4">Qualifications</h2>
            <ul className="space-y-4 mb-10 text-slate-700">
              <li className="flex items-start">
                <span className="text-emerald-500 mr-3 mt-1">✓</span>
                <span>Must have completed or be willing to complete the Life License Qualification Program (LLQP)</span>
              </li>
              <li className="flex items-start">
                <span className="text-emerald-500 mr-3 mt-1">✓</span>
                <span>Strong communication and interpersonal skills</span>
              </li>
              <li className="flex items-start">
                <span className="text-emerald-500 mr-3 mt-1">✓</span>
                <span>A background in finance, business, or a related field is a plus but not required</span>
              </li>
              <li className="flex items-start">
                <span className="text-emerald-500 mr-3 mt-1">✓</span>
                <span>Experience in sales, advising, customer service, or any role where you guide people toward solutions</span>
              </li>
            </ul>

            <h2 className="text-2xl font-bold text-slate-900 mb-4">What We Offer</h2>
            <ul className="space-y-4 mb-10 text-slate-700">
              <li className="flex items-start">
                <span className="text-emerald-500 mr-3 mt-1">✓</span>
                <span>Access to a wide range of insurance and investment products</span>
              </li>
              <li className="flex items-start">
                <span className="text-emerald-500 mr-3 mt-1">✓</span>
                <span>Training and mentorship opportunities</span>
              </li>
              <li className="flex items-start">
                <span className="text-emerald-500 mr-3 mt-1">✓</span>
                <span>Flexible career growth in the financial services industry</span>
              </li>
              <li className="flex items-start">
                <span className="text-emerald-500 mr-3 mt-1">✓</span>
                <span>The opportunity to help individuals and families make confident financial decisions</span>
              </li>
            </ul>
            
            <a href="mailto:careers@maplesolutionsgroup.ca" className="inline-block bg-emerald-600 hover:bg-emerald-700 text-white px-8 py-3 rounded-full font-medium transition-colors">
              Apply Now
            </a>
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
}
