import { NextResponse } from 'next/server';
import { Client } from '@hubspot/api-client';

export async function POST(req: Request) {
  try {
    const data = await req.json();
    const { firstName, email, phone, insuranceType, employmentStatus, citizenship, cityOrPostal, workedWithAdvisor } = data;

    const hubspotAccessToken = process.env.HUBSPOT_ACCESS_TOKEN;
    const contactEmail = process.env.CONTACT_EMAIL;

    // EmailJS Configuration
    const emailJsServiceId = process.env.EMAILJS_SERVICE_ID || "service_4by8rg9";
    const emailJsAdminTemplateId = process.env.EMAILJS_ADMIN_TEMPLATE_ID || "template_52lucz6";
    const emailJsClientTemplateId = process.env.EMAILJS_CLIENT_TEMPLATE_ID || "template_wei5zkw";
    const emailJsPublicKey = process.env.EMAILJS_PUBLIC_KEY || "MrPEtxgBr1xFxZfa2";

    if (!process.env.EMAILJS_SERVICE_ID || !process.env.EMAILJS_PUBLIC_KEY) {
      console.warn('Missing EmailJS environment variables. Using default placeholders.');
    }

    const sendEmailJs = async (templateId: string, templateParams: any) => {
      try {
        const response = await fetch("https://api.emailjs.com/api/v1.0/email/send", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            service_id: emailJsServiceId,
            template_id: templateId,
            user_id: emailJsPublicKey,
            template_params: templateParams
          })
        });
        if (!response.ok) {
          const text = await response.text();
          console.error(`EmailJS Error (${templateId}):`, text);
        } else {
          console.log(`EmailJS Success (${templateId})`);
        }
      } catch (err) {
        console.error(`EmailJS Exception (${templateId}):`, err);
      }
    };

    const templateParams = {
      firstName: firstName || '',
      email: email || '',
      phone: phone || '',
      insuranceType: insuranceType || '',
      employmentStatus: employmentStatus || '',
      citizenship: citizenship || '',
      cityOrPostal: cityOrPostal || '',
      workedWithAdvisor: workedWithAdvisor || '',
    };

    // Send admin email
    if (contactEmail) {
      await sendEmailJs(emailJsAdminTemplateId, {
        ...templateParams,
        to_email: contactEmail, 
      });
    } else {
       console.warn('Missing CONTACT_EMAIL for admin email. Sending admin email to info@maplesolutionsgroup.ca');
       await sendEmailJs(emailJsAdminTemplateId, {
         ...templateParams,
         to_email: 'info@maplesolutionsgroup.ca',
       });
    }

    // Send client email
    if (email) {
      await sendEmailJs(emailJsClientTemplateId, {
        ...templateParams,
        to_email: email, 
        to_name: firstName,
      });
    }

    // 2. Add to HubSpot
    if (hubspotAccessToken) {
      try {
        const hubspotClient = new Client({ accessToken: hubspotAccessToken });
        const properties: Record<string, string> = {
          firstname: firstName || '',
          email: email || '',
          phone: phone || '',
          lifecyclestage: 'lead',
          insurance_type: insuranceType || '',
          employment_status: employmentStatus || '',
          citizenship_status: citizenship || '',
          city_or_postal_code: cityOrPostal || '',
          worked_with_advisor_before: workedWithAdvisor || ''
        };

        console.log('Sending this EXACT payload to HubSpot CRM:', JSON.stringify({ properties }, null, 2));

        await hubspotClient.crm.contacts.basicApi.create({
          properties,
        });
      } catch (hubspotError) {
        console.error('HubSpot API Error:', hubspotError);
      }
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Submission error:', error);
    return NextResponse.json({ success: false, error: 'Failed to submit' }, { status: 500 });
  }
}
