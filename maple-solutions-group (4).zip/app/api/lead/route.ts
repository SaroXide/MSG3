import { NextResponse } from 'next/server';

export async function POST(request: Request) {
  try {
    const data = await request.json();

    const contactEmail = process.env.CONTACT_EMAIL;
    const hubspotToken = process.env.HUBSPOT_ACCESS_TOKEN;

    if (!hubspotToken) {
      console.warn("No HUBSPOT_ACCESS_TOKEN configured. Skipping HubSpot integration.");
    }
    if (!contactEmail) {
      console.warn("No CONTACT_EMAIL configured.");
    }

    const results = {
      hubspotSent: false,
      errors: [] as string[],
    };

    // 1. Send to HubSpot (if configured)
    if (hubspotToken) {
      try {
        const hubspotResponse = await fetch('https://api.hubapi.com/crm/v3/objects/contacts', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${hubspotToken}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            properties: {
              email: data.email,
              firstname: data.firstName,
              phone: data.phone,
              jobtitle: data.employmentStatus,
              city: data.cityOrPostal,
              hs_lead_status: "NEW",
              message: `Insurance Type: ${data.insuranceType}\nCitizenship: ${data.citizenship}\nWorked with advisor: ${data.workedWithAdvisor}`
            }
          })
        });

        if (!hubspotResponse.ok) {
          const errorData = await hubspotResponse.json();
          console.error('HubSpot Error:', errorData);
          results.errors.push('HubSpot integration failed');
        } else {
          results.hubspotSent = true;
        }
      } catch (err) {
        console.error('HubSpot Request Failed:', err);
        results.errors.push('HubSpot request failed');
      }
    }

    // If HubSpot is not configured, we still return success for the UI simulation,

    return NextResponse.json({ success: true, results });
  } catch (error) {
    console.error('Error processing lead:', error);
    return NextResponse.json({ error: 'Failed to process lead' }, { status: 500 });
  }
}
