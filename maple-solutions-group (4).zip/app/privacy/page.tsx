import Header from '@/components/Header';
import Footer from '@/components/Footer';

export default function PrivacyPolicy() {
  return (
    <>
      <Header />
      <main className="bg-slate-50 min-h-screen">
        <div className="relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-amber-50 via-emerald-50/30 to-white -z-10" />
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-24">
            <h1 className="text-4xl md:text-5xl font-extrabold text-slate-900 mb-8 text-center">Privacy Policy</h1>
          </div>
        </div>

        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 pb-24">
          <div className="bg-white rounded-3xl p-8 md:p-12 border border-slate-200 shadow-xl shadow-slate-200/50 prose prose-slate prose-emerald max-w-none">
            <p className="text-slate-700 mb-6 text-lg">
              At Maple Solutions Group, we value your privacy and are committed to protecting your personal information. This Privacy Policy explains how we collect, use, and safeguard the information you provide when using our website or contacting us.
            </p>
            <p className="text-slate-700 mb-10 text-lg">
              By using our website or submitting your information through our forms, you agree to the practices described in this policy.
            </p>

            <hr className="border-slate-200 my-10" />

            <h2 className="text-2xl font-bold text-slate-900 mt-10 mb-4">1. Information Collection</h2>
            <p className="text-slate-700 mb-4">
              When you use our website or complete a form, we may collect personal information such as your name, phone number, email address, and other information related to your insurance needs.
            </p>
            <p className="text-slate-700 mb-4">
              This information allows a licensed insurance advisor from Maple Solutions Group to contact you and discuss suitable coverage options.
            </p>
            <p className="text-slate-700 mb-10">
              Advisors at Maple Solutions Group are licensed under Ontario&apos;s Life License Qualification Program (LLQP).
            </p>

            <hr className="border-slate-200 my-10" />

            <h2 className="text-2xl font-bold text-slate-900 mt-10 mb-4">2. How We Use Your Information</h2>
            <p className="text-slate-700 mb-4">
              We use your information to:
            </p>
            <ul className="list-disc pl-6 text-slate-700 mb-6 space-y-2">
              <li>Contact you to discuss your insurance needs</li>
              <li>Provide information about insurance and financial protection options</li>
              <li>Improve our website and services</li>
            </ul>
            <p className="text-slate-700 mb-4">
              We do not sell or rent your personal information to third parties.
            </p>
            <p className="text-slate-700 mb-10">
              Your information may be shared with licensed advisors or insurance providers only when necessary to assist with your request or provide insurance services.
            </p>

            <hr className="border-slate-200 my-10" />

            <h2 className="text-2xl font-bold text-slate-900 mt-10 mb-4">3. Compensation Disclosure</h2>
            <p className="text-slate-700 mb-4">
              Licensed advisors at Maple Solutions Group may receive commissions from insurance providers if a policy is purchased.
            </p>
            <p className="text-slate-700 mb-10">
              These commissions are paid by the insurance company and do not increase the cost of your policy.
            </p>

            <hr className="border-slate-200 my-10" />

            <h2 className="text-2xl font-bold text-slate-900 mt-10 mb-4">4. Consent</h2>
            <p className="text-slate-700 mb-4">
              By submitting your information through our website, you consent to being contacted by Maple Solutions Group by phone, email, or SMS regarding insurance products and services.
            </p>
            <p className="text-slate-700 mb-4">
              You may withdraw your consent or request deletion of your personal information at any time by contacting us at:
            </p>
            <p className="text-slate-700 mb-10">
              📧 <a href="mailto:info@maplesolutionsgroup.ca" className="text-emerald-600 hover:text-emerald-700 font-medium">info@maplesolutionsgroup.ca</a>
            </p>

            <hr className="border-slate-200 my-10" />

            <h2 className="text-2xl font-bold text-slate-900 mt-10 mb-4">5. Data Protection</h2>
            <p className="text-slate-700 mb-10">
              We use reasonable security measures to protect your personal information from unauthorized access, misuse, or disclosure. Access to personal data is limited to authorized personnel only.
            </p>

            <hr className="border-slate-200 my-10" />

            <h2 className="text-2xl font-bold text-slate-900 mt-10 mb-4">6. Your Rights</h2>
            <p className="text-slate-700 mb-4">
              Under Canadian privacy law, including the Personal Information Protection and Electronic Documents Act (PIPEDA), you have the right to request access to, correction of, or deletion of your personal information.
            </p>
            <p className="text-slate-700 mb-10">
              To make a request, please contact us using the information provided below.
            </p>

            <hr className="border-slate-200 my-10" />

            <h2 className="text-2xl font-bold text-slate-900 mt-10 mb-4">7. Terms of Service</h2>
            <h3 className="text-xl font-semibold text-slate-800 mt-6 mb-2">General</h3>
            <p className="text-slate-700 mb-6">
              By accessing or using this website, you agree to these Terms of Service.
            </p>

            <h3 className="text-xl font-semibold text-slate-800 mt-6 mb-2">No Guarantees</h3>
            <p className="text-slate-700 mb-6">
              Insurance coverage options and product availability may vary depending on your personal circumstances, underwriting requirements, and insurance provider policies.
            </p>

            <h3 className="text-xl font-semibold text-slate-800 mt-6 mb-2">Limitation of Liability</h3>
            <p className="text-slate-700 mb-6">
              Maple Solutions Group is not responsible for any financial decisions made by users of this website. Insurance policies are issued and underwritten by third party insurance companies.
            </p>

            <h3 className="text-xl font-semibold text-slate-800 mt-6 mb-2">Policy Changes</h3>
            <p className="text-slate-700 mb-10">
              We may update this Privacy Policy or Terms of Service from time to time. Any updates will be posted on this page with a revised date.
            </p>

            <hr className="border-slate-200 my-10" />

            <h2 className="text-2xl font-bold text-slate-900 mt-10 mb-4">8. Licensing Disclosure</h2>
            <p className="text-slate-700 mb-4">
              Advisors at Maple Solutions Group are licensed insurance professionals under Ontario&apos;s Life License Qualification Program (LLQP).
            </p>
            <p className="text-slate-700 mb-4">
              Maple Solutions Group advisors are licensed and contracted through World Financial Group Insurance Agency of Canada Inc.
            </p>
            <p className="text-slate-700 mb-10">
              Insurance products are offered through licensed advisors and are underwritten by third party insurance providers.
            </p>

            <hr className="border-slate-200 my-10" />

            <h2 className="text-2xl font-bold text-slate-900 mt-10 mb-4">9. Contact Us</h2>
            <p className="text-slate-700 mb-4">
              If you have questions about this Privacy Policy or Terms of Service, please contact us:
            </p>
            <p className="text-slate-700 mb-2">
              📧 <a href="mailto:info@maplesolutionsgroup.ca" className="text-emerald-600 hover:text-emerald-700 font-medium">info@maplesolutionsgroup.ca</a>
            </p>
            <p className="text-slate-700 mb-10">
              📍 Ontario, Canada
            </p>
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
}
