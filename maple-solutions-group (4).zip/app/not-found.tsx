import Link from 'next/link';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

export default function NotFound() {
  return (
    <>
      <Header />
      <main className="relative min-h-[70vh] overflow-hidden bg-slate-50">
        <div className="absolute inset-0 bg-gradient-to-br from-amber-50 via-emerald-50/30 to-white -z-10" />
        <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-24 text-center">
          <div className="bg-white rounded-3xl shadow-xl shadow-slate-200/50 border border-slate-200 p-10 md:p-14">
            <p className="text-emerald-600 font-semibold mb-2">404</p>
            <h1 className="text-4xl md:text-5xl font-extrabold text-slate-900 mb-4">
              Page not found
            </h1>
            <p className="text-lg text-slate-600 mb-8">
              Sorry, we couldn&apos;t find the page you&apos;re looking for.
            </p>
            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <Link
                href="/"
                className="bg-emerald-600 hover:bg-emerald-700 text-white px-8 py-3 rounded-full font-medium transition-colors"
              >
                Go home
              </Link>
              <Link
                href="/contact"
                className="bg-white hover:bg-slate-50 text-emerald-700 border-2 border-emerald-200 px-8 py-3 rounded-full font-medium transition-colors"
              >
                Contact us
              </Link>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
}
