import Header from '@/components/Header';
import Footer from '@/components/Footer';
import LeadForm from '@/components/LeadForm';
import { CheckCircle2, ShieldCheck, Users, Globe, Star, HeartPulse, Activity, AlertCircle, Home as HomeIcon, Briefcase, TrendingUp, ArrowRight } from 'lucide-react';
import Image from 'next/image';

export default function Home() {
  return (
    <>
      <Header />
      
      {/* Hero Section */}
      <section className="relative overflow-hidden pt-8 pb-24 lg:pt-12 lg:pb-32">
        <div className="absolute inset-0 bg-gradient-to-br from-amber-50 via-emerald-50/30 to-white -z-10" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-start">
            
            {/* Left Column: Copy */}
            <div className="max-w-2xl">
              <h1 className="text-5xl lg:text-6xl font-extrabold text-slate-900 tracking-tight leading-tight mb-6">
                Insurance Made Simple. <span className="text-emerald-600">Affordable Coverage</span> for Ontario Families.
              </h1>
              <p className="text-xl text-slate-600 mb-8 leading-relaxed">
                Get personalized insurance advice from a licensed advisor. With access to 40+ insurance providers, we compare coverage options to help you find the right protection for your family, your goals, and your budget.
              </p>
              
              <div className="space-y-4 mb-10">
                <div className="flex items-start">
                  <CheckCircle2 className="w-6 h-6 text-emerald-500 mr-3 flex-shrink-0 mt-0.5" />
                  <p className="text-slate-700 font-medium">Access to 40+ leading insurance providers</p>
                </div>
                <div className="flex items-start">
                  <CheckCircle2 className="w-6 h-6 text-emerald-500 mr-3 flex-shrink-0 mt-0.5" />
                  <p className="text-slate-700 font-medium">Handpicked, experienced, and professional advisors</p>
                </div>
                <div className="flex items-start">
                  <CheckCircle2 className="w-6 h-6 text-emerald-500 mr-3 flex-shrink-0 mt-0.5" />
                  <p className="text-slate-700 font-medium">Advisors who speak your language, servicing all of Ontario</p>
                </div>
              </div>
              
              <div className="flex flex-col sm:flex-row items-center sm:justify-start gap-4">
                <a href="#lead-form" className="w-full sm:w-auto flex items-center justify-center bg-emerald-600 hover:bg-emerald-700 text-white px-8 py-4 rounded-full font-bold text-lg transition-transform hover:scale-105 shadow-lg shadow-emerald-600/20 whitespace-nowrap">
                  <span className="lg:hidden">Find My Advisor</span>
                  <span className="hidden lg:inline">Complete the form</span>
                  <ArrowRight className="hidden lg:block w-5 h-5 ml-2" />
                </a>

                <a href="tel:4378002223" className="w-full sm:w-auto bg-white hover:bg-slate-50 text-slate-900 border-2 border-slate-200 px-8 py-4 rounded-full font-bold text-lg text-center transition-colors whitespace-nowrap">
                  Call (437) 800-2223
                </a>
              </div>
            </div>
            
            {/* Right Column: Lead Form */}
            <div className="relative z-10">
              <div className="absolute inset-0 bg-gradient-to-tr from-amber-200 to-emerald-100 rounded-3xl transform rotate-3 scale-105 -z-10 opacity-50" />
              <LeadForm />
            </div>
            
          </div>
        </div>
      </section>

      {/* Logos Section */}
      <section className="py-12 bg-white border-b border-slate-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p className="text-sm font-semibold text-slate-500 uppercase tracking-wider mb-8">
            Our advisors work with 40+ leading providers including
          </p>
          <div className="flex flex-wrap justify-center gap-8 md:gap-16 opacity-60 grayscale hover:grayscale-0 transition-all duration-500">
            {/* Placeholder for logos */}
            <span className="text-xl font-bold font-serif text-slate-800">Manulife</span>
            <span className="text-xl font-bold font-serif text-slate-800">Industrial Alliance</span>
            <span className="text-xl font-bold font-serif text-slate-800">Foresters</span>
            <span className="text-xl font-bold font-serif text-slate-800">Equitable Life</span>
            <span className="text-xl font-bold font-serif text-slate-800">Empire Life</span>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-24 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-4xl font-bold text-slate-900 mb-4">Explore What Our Trusted Advisors Can Help You With</h2>
            <p className="text-lg text-slate-600">We do all sorts of insurance. Whether you want to protect your family, your health, or your future wealth, we will help you find an advisor who gets it right.</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              { title: 'Life Insurance', desc: 'Protect your loved ones with affordable term, whole, or universal life coverage.', icon: HeartPulse },
              { title: 'Health & Disability', desc: 'Get coverage that helps with medical costs and protects your income if you can’t work.', icon: Activity },
              { title: 'Critical Illness', desc: 'Receive a payment if you’re diagnosed with a serious condition like cancer or heart disease.', icon: AlertCircle },
              { title: 'Home & Auto Insurance', desc: 'Get coverage that protects your home, car, and personal belongings from unexpected loss or damage.', icon: HomeIcon },
              { title: 'Business Insurance', desc: 'Coverage for small businesses, including liability and protection for business assets.', icon: Briefcase },
              { title: 'Investments & Retirement', desc: 'Grow your savings and plan for a secure future with RRSPs, TFSAs, and other investment options.', icon: TrendingUp },
            ].map((service, i) => (
              <div key={i} className="bg-white rounded-2xl p-8 border border-slate-200 hover:shadow-lg transition-shadow">
                <div className="w-12 h-12 bg-emerald-100 rounded-xl flex items-center justify-center mb-6 text-emerald-600">
                  <service.icon className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-bold text-slate-900 mb-3">{service.title}</h3>
                <p className="text-slate-600 leading-relaxed">{service.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-24 bg-amber-50/50 text-slate-900 border-t border-amber-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-4xl font-bold mb-6 text-slate-900">Why Maple Solutions Group?</h2>
              <p className="text-xl text-slate-700 mb-8 leading-relaxed">
                We are a small team based in Ontario dedicated to making insurance simple. Our licensed advisors provide clear guidance, transparent options, and access to coverage from more than 40 providers, helping you find protection that fits your needs and your budget.
              </p>
              
              <ul className="space-y-6">
                <li className="flex">
                  <div className="flex-shrink-0 mt-1">
                    <div className="w-10 h-10 bg-emerald-200 rounded-lg flex items-center justify-center text-emerald-700">
                      <Users className="w-5 h-5" />
                    </div>
                  </div>
                  <div className="ml-4">
                    <h4 className="text-lg font-bold text-slate-900">Handpicked Professionals</h4>
                    <p className="text-slate-600 mt-1">Advisors at Maple Solutions Group are licensed and trusted to provide clear, personalized insurance solutions, helping you find coverage that fits your needs.</p>
                  </div>
                </li>
                <li className="flex">
                  <div className="flex-shrink-0 mt-1">
                    <div className="w-10 h-10 bg-emerald-200 rounded-lg flex items-center justify-center text-emerald-700">
                      <Globe className="w-5 h-5" />
                    </div>
                  </div>
                  <div className="ml-4">
                    <h4 className="text-lg font-bold text-slate-900">Multilingual Support</h4>
                    <p className="text-slate-600 mt-1">Our licensed advisors speak multiple languages so you can fully understand your insurance options and make confident decisions.</p>
                  </div>
                </li>
              </ul>
            </div>
            
            <div className="relative w-full aspect-[4/3] lg:aspect-auto lg:h-[500px] rounded-3xl overflow-hidden shadow-xl ring-1 ring-black/5 bg-slate-50">
              <Image
                src="/home-hero.png"
                alt="Advisor talking to a family client"
                fill
                className="object-contain lg:object-cover"
                referrerPolicy="no-referrer"
                unoptimized
              />
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-24 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-4xl font-bold text-slate-900 mb-4">What Our Clients Say</h2>
            <p className="text-lg text-slate-600">Real stories from Canadians who found their perfect advisor match through us.</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                name: 'Aisha R.',
                location: 'Mississauga',
                text: 'Super fast and easy. I filled out the form in a minute and spoke with a licensed advisor the same day. They walked me through my options and helped me set up life and critical illness insurance within a week.',
              },
              {
                name: 'Moe S.',
                location: 'Toronto',
                text: 'I run a small business and needed help with coverage and investments. Elena helped me get the right business insurance and also a personal investment plan.',
              },
              {
                name: 'Katy D.',
                location: 'Markham',
                text: 'I was nervous about finding the right insurance, and I wasn’t sure if they would speak Farsi, but thankfully Darya, a licensed advisor at Maple Solutions Group, spoke Farsi and helped me. She listened carefully, explained everything clearly, and I ended up saving money while getting better coverage.',
              },
            ].map((testimonial, i) => (
              <div key={i} className="bg-white rounded-2xl p-8 shadow-sm border border-slate-100 flex flex-col h-full">
                <div className="flex text-amber-400 mb-4">
                  {[...Array(5)].map((_, j) => <Star key={j} className="w-5 h-5 fill-current" />)}
                </div>
                <p className="text-slate-700 mb-6 italic flex-grow">&quot;{testimonial.text}&quot;</p>
                <div>
                  <p className="font-bold text-slate-900">{testimonial.name}</p>
                  <p className="text-sm text-slate-500">{testimonial.location}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-24 bg-emerald-600 text-white text-center">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-4xl font-bold mb-6">Ready to find the right coverage?</h2>
          <p className="text-xl text-emerald-100 mb-10">
            Call us or have us contact you. Let us connect so we can help you find the right coverage.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a href="#lead-form" className="bg-white text-emerald-600 px-10 py-4 rounded-full font-bold text-lg hover:bg-slate-50 transition-transform hover:scale-105 shadow-xl">
              Find My Advisor
            </a>
            <a href="tel:4378002223" className="bg-transparent hover:bg-emerald-700 text-white border-2 border-white px-10 py-4 rounded-full font-bold text-lg transition-colors">
              Call (437) 800-2223
            </a>
          </div>
        </div>
      </section>

      <Footer />
    </>
  );
}
