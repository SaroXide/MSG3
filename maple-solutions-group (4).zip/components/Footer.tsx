import React from 'react';
import Image from 'next/image';
import Link from 'next/link';

export default function Footer() {
  return (
    <footer className="bg-slate-900 text-slate-300 py-12 border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center space-x-2 mb-6">
              <div className="relative w-8 h-8 flex items-center justify-center">
                <Image
                  src="/logo.png"
                  alt="Maple Solutions Logo"
                  fill
                  className="object-contain"
                  referrerPolicy="no-referrer"
                  sizes="32px"
                  unoptimized
                />
              </div>
              <span className="font-bold text-xl text-white tracking-tight">Maple Solutions Group</span>
            </div>
            <p className="text-slate-400 max-w-sm mb-6">
              Licensed insurance advisors helping Canadians find coverage that fits their needs, goals, and budget.
            </p>
            <p className="text-sm text-slate-500">
              Servicing all over Ontario, Canada.
            </p>
          </div>
          
          <div>
            <h4 className="text-white font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-3">
              <li><Link href="/" className="hover:text-emerald-400 transition-colors">Home</Link></li>
              <li><Link href="/about" className="hover:text-emerald-400 transition-colors">About Us</Link></li>
              <li><Link href="/careers" className="hover:text-emerald-400 transition-colors">Careers</Link></li>
              <li><Link href="/contact" className="hover:text-emerald-400 transition-colors">Contact</Link></li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-white font-semibold mb-4">Contact</h4>
            <ul className="space-y-3">
              <li>
                <a href="tel:4378002223" className="hover:text-emerald-400 transition-colors">
                  (437) 800-2223
                </a>
              </li>
              <li>
                <a href="mailto:info@maplesolutionsgroup.ca" className="hover:text-emerald-400 transition-colors">
                  info@maplesolutionsgroup.ca
                </a>
              </li>
              <li className="pt-4">
                <Link href="/privacy" className="hover:text-emerald-400 transition-colors">
                  Privacy Policy
                </Link>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-slate-800 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-sm text-slate-500">
            &copy; {new Date().getFullYear()} Maple Solutions Group. All rights reserved.
          </p>
          <p className="text-sm text-slate-500 mt-4 md:mt-0">
            We work with 40+ leading insurance providers.
          </p>
        </div>
      </div>
    </footer>
  );
}
